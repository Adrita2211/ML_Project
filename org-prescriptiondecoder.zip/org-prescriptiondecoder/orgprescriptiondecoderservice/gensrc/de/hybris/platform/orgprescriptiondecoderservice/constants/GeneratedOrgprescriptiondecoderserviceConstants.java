/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 6, 2025, 3:05:45 PM                     ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2025 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.platform.orgprescriptiondecoderservice.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedOrgprescriptiondecoderserviceConstants
{
	public static final String EXTENSIONNAME = "orgprescriptiondecoderservice";
	
	protected GeneratedOrgprescriptiondecoderserviceConstants()
	{
		// private constructor
	}
	
	
}
